<?php


namespace Drupal\article\Plugin\Block;

use Drupal\Core\Block\BlockBase;
use \Drupal\Core\Url;//
use Drupal\Core\Entity;
use Drupal\Core\Render\RendererInterface;
use Drupal\taxonomy\Entity\Term;//
use Symfony\Component\HttpFoundation\JsonResponse;


/**
 * Provides a 'article' block.
 *
 * @Block(
 *   id = "article_block",
 *   admin_label = @Translation("Article block"),
 *   category = @Translation("Custom article block example")
 * )
 */
class ArticleBlock extends BlockBase {

  /**
   * {@inheritdoc}
   */
 /* public function build() {
    return array(
      '#type' => 'markup',
      '#markup' => 'This block list the article.',
    );
  }*/

/*public function build() {

       $form = \Drupal::formBuilder()->getForm('Drupal\article\Form\SearchForm');

       return $form;
     }
   }
*/

   public function build() {
    

   $query = \Drupal::entityQuery('node');
    //$query->condition('field_zipcode', $val);
   // $query->condition('field_taxtype', $type);
    $entity_ids = $query->execute();
     $nodes=\Drupal\node\Entity\Node::loadMultiple($entity_ids);

     foreach ($nodes as $node) {
      //echo "<pre>";
      //print_r($node);  
         //$address = $node->field_addres->value;
         //$name = $node->field_name1->value;
         $taxType = $node->field_taxtype->target_id;
         

         //$tax = $taxType->label();
      // $address = $node->get('field_addres')->getValue(); 
     }



     

$str = "taxType=".$taxType;
 $build = [];
    $build['hello_block']['#markup'] =$str;
  return $build;
  }
  
}

