<?php
namespace Drupal\horizonform\Form;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\Core\Database\Database;
use Drupal\Core\Database\entityQuery;
use Drupal\taxonomy\Entity\Term;

class Doctorform extends FormBase

{
	public function getFormId(){
	 	return 'horizon_page';
	}
	public function buildForm(array $form, FormStateInterface $form_state){

		 $vid = 'provider_type';
        $provider =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree($vid);
        foreach ($provider as $term) {
        $provider_data[$term->tid] = $term->name;
     }
       $vid1 = 'choose_your_plan';
        $plans =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree($vid1);
        foreach ($plans as $term) {
        $plan_data[$term->tid] = $term->name;
     }

       $vid2 = 'location_radius';
        $radius =\Drupal::entityTypeManager()->getStorage('taxonomy_term')->loadTree($vid2);
        foreach ($radius as $term) {
        $radius_data[$term->tid] = $term->name;
     }
    // $term_data = array_flip($term_data);
       //print_r($term_data);die;

          $form['Provider_Type'] = array(
          '#type' => 'select',
          '#title' => t('Choose Provider Type'),

          //'#multiple' => true,

          '#options' => $provider_data,
      );

             $form['Choose_Type'] = array(
          '#type' => 'select',
          '#title' => t('Choose Your Plan'),
          //'#multiple' => true,
          '#options' => $plan_data,
      );

           $form['autocomplete'] = [
              '#type' => 'entity_autocomplete',
              '#target_type' => 'taxonomy_term',
              '#placeholder' => 'Enter doctor name, specialty, service or affiliation',
              '#selection_settings' => [
             'target_bundles' => ['hospital_name'], // Required. The bundle name for the new entity.
    //'uid' => <a valid user ID>, // Optional. The user ID for the new entity, if the target entity type implements \Drupal\user\EntityOwnerInterface. Defaults to the current logged-in user.
  ],
];
              $form['Enter_Location'] = array(
          '#type' => 'textfield',
          '#title' => t('Enter Location'),
          //'#multiple' => true,
          '#placeholder' => t('Street address, city, zip code, or county')
          
      );
             $form['location_radius'] = array(
          '#type' => 'select',
          '#title' => t('Location Radius'),
          //'#multiple' => true,
          '#options' => $radius_data,
      );
             $form['submit']=array(
      '#type'=>'submit',
      '#value'=> $this->t('FIND'),
    );
              $form['#theme'] = 'horizon_page';

        return $form;
     }

    public function submitForm(array &$form, FormStateInterface $form_state) {


    }
}
?>