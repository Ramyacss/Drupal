<?php
namespace Drupal\horizonform\Controller;

class DefaultController 
{

  public function horizon_content() {
  	$form = \Drupal::formBuilder()->getForm('Drupal\horizonform\Form\Doctorform');
  	return $form;
  
  }
}

    



?>