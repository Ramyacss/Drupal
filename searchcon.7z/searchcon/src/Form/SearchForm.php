<?php
namespace Drupal\searchcon\Form;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\Core\Database\Database;

class SearchForm extends FormBase{

	public function getFormId(){
		return 'searchform';
	}

	public function buildForm(array $form, FormStateInterface $form_state){


$form['Types'] = [
  '#type' => 'entity_autocomplete',
  '#target_type' => 'taxonomy_term',
  '#title' =>  t('Doctors Types  :'),
];


/*$form['Name']=array(
'#type' => 'textfield',
'#title' => t('Name'),
'#required' => TRUE,
		);

$form['Adress']=array(
'#type' => 'textfield',
'#title' => t('Adress'),
'#required' => TRUE,
		);

/*	$form['Types']=array(
'#type'=>'select',
'#title' => t('doctors content searching :'),
'#options'=>array('Doctor' => "Doctor",'Dentist' => "Dentist",'Hospital' => "Hospital"),
'#required' => TRUE,
		);
*/
$form['search']=array(
			'#type' => 'textfield',
			'#title' => t('Zipcode'),
			'#required' => TRUE,
		);
		$form['submit']=array(
			'#type'=>'submit',
			'#value'=> $this->t('Submit'),
		);
		return $form;
	}

	public function submitForm(array &$form, FormStateInterface $form_state){
		
		$values=$form_state->getValues();
		$searchValue= $values["search"];
		//$searchType = $values["Types"];
		$url = Url::fromRoute('searchcon.display', array('val' => $searchValue));
		$form_state->setRedirectUrl($url);
		}
	}
?>
