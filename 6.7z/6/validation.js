
    function grabSearch(){

    var search=document.getElementById('search_box').value;
    if(search === "Search" || search === ""){
    document.getElementById('search_box').value="Please Enter a keyword";
    return false;
}