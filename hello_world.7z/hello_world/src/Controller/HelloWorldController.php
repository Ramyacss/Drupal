<?php
namespace drupal\hello_world\controller;
class helloworldcontroller{
	public function hello(){
		return array(
		'#title'=>'Drupal world',
		'#markup'=>'Welcome to Drupal World',
		);
	}
}