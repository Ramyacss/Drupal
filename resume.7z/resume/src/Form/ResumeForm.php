<?php
namespace Drupal\resume\Form;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
class ResumeForm extends FormBase {
  public function getFormId() {
    return 'resume_form';
  }
  public function buildForm(array $form, FormStateInterface $form_state) {
    $form['candidate_name'] = array(
      '#type' => 'textfield',
      '#title' => t('Candidate Name:'),
      '#required' => TRUE,
    );
    $form['candidate_mail'] = array(
      '#type' => 'email',
      '#title' => t('Email ID:'),
      '#required' => TRUE,
    );
    $form['number'] = array(
      '#type' => 'tel',
      '#title' => t('Mobile no:'),
    );


$form['comment'] = array(
       '#type' => 'textfield',
       '#title' => t('comment'),
     );





   $form['customer_feedback']=array(
    '#type'=>'textarea',
    '#title'=>t('Feedback'),
    '#required'=>TRUE,
    '#id'=>'fb',
    );

    $form['DOB'] = array (
      '#type' => 'date',
      '#title' => t('DOB'),
      '#required' => TRUE,
    );
    $form['Gender'] = array (
      '#type' => 'select',
      '#title' => ('Gender'),
      '#options' => array(
        'Female' => t('Female'),
        'male' => t('Male'),
      ),
    );
    $form['confirmation'] = array (
      '#type' => 'radios',
      '#title' => ('Are you above 18 years'),
      '#options' => array(
        'Yes' =>t('Yes'),
        'No' =>t('No')
      ),
    );

    $form['candidate_copy'] = array(
      '#type' => 'checkbox',
      '#title' => t('Send me a copy of the application:'),
    );
    $form['actions']['#type'] = 'actions';
    $form['actions']['submit'] = array(
      '#type' => 'submit',
      '#value' => $this->t('Save'),
      '#button_type' => 'primary',
    );
    $form['#theme']='resume_form';
    return $form;
  }
  public function validateForm(array &$form, FormStateInterface $form_state) {
      if (strlen($form_state->getValue('number')) < 10) {
        $form_state->setErrorByName('number', $this->t('Mobile number is too short.'));
      }
  }
  public function submitForm(array &$form, FormStateInterface $form_state) {
      foreach ($form_state->getValues() as $key => $value) {
      drupal_set_message($key . ': ' . $value);
    }
   }
}
  ?>