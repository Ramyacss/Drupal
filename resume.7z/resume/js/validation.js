function validate_email(){
	var x=document.getElementById('email').value;
	var atpos=x.indexOf("@");
	var dotpos=x.indexOf(".");
	if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length){
	alert("please enter a valid email id");
	}
	console.log("gets in");
}