$= jQuery;

function horizonblue_form(){
	}
	/*
$('go-btn').on('click',function(){
	alert($("#my-dropdown").val());
});*/




$(function() {
    console.log( "ready!" );
    $("#edit-providers").change(function(){
        var selectedContent = $(this).children("option:selected").val();
        alert("You have selected the content - " + selectedContent);
    })
});