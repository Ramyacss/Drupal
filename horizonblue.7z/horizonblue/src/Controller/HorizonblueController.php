<?php

namespace Drupal\horizonblue\Controller;
use Drupal\Core\Database\Database;
use Drupal\Core\Url;
class HorizonblueController {
	public function listSearch(){
		 	
return array(
		'#title'=>'Drupal',
		'#markup'=>'providers list',
		);
	}
}
?>