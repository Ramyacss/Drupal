<?php
namespace Drupal\horizonblue\Form;
use Drupal\Core\Form\FormBase;
use Drupal\Core\Form\FormStateInterface;
use Drupal\Core\Url;
use Drupal\Core\Database\Database;

class Horizonform extends FormBase
{
	public function getFormId(){
	 	return 'horizonform';
	}
	public function buildForm(array $form, FormStateInterface $form_state){


		 $client = \Drupal::httpClient();
		 $request = $client->get('http://dde.horizonblue.com/provider/api/search?providertype=D', [
    'auth' => ['siteadmin','admin123']
  ]);
  $response = $request->getBody();
  //echo "<pre>";
$result= json_decode($response);
//print_r($result->providers);

	$form['Providers']=array(
        '#type'=>'select',
        '#title' => t('Doctors content searching :'),
        '#options'=>array('Doctor' => "Doctor",'Dentist' => "Dentist",'Hospitals' => "Hospitals",'Other Healthcare Services' => "Other Healthcare Services"),
        '#required' => TRUE,
		);
	$form["ChoosePlan"] = array(
		'#type' => 'select',
        '#title' => t('Choose a Plan to Start'),
        '#options'=>array('Omnia Bronze' => "Omnia Bronze",'Omnia Glod' => "Omnia Glod",'Omnia HSA' => "Omnia HSA",'Omnia Sliver' => "Omnia Sliver"),
       // '#required' => TRUE,
        );
	$form['zipcode']=array(
			'#type' => 'textfield',
			'#title' => t('Zipcode'),
			//'#required' => TRUE,
		);
	$form['Specialty']=array(
			'#type' => 'select',
			'#title' => t('Specialty'),
			'#options'=>array( 'Orthopedic Surgery' => "Orthopedic Surgery",'Licensed Professional Counselor' => "Licensed Professional Counselor",'Pediatric Gastroenterology' => "Pediatric Gastroenterology" ),
			//'#required' => TRUE,
		);
	$form['Doctors_Lname']=array(
			'#type' => 'textfield',
			'#title' => t('Doctors Last Name'),
		);
			//'#required' => TRUE,
	$form['Affiliations']=array(
			'#type' => 'textfield',
			'#title' => t('Doctor Affiliations'),
		);
	$form['submit']=array(
			'#type'=>'submit',
			'#value'=> $this->t('Submit'),
			//'#button_type'=>'primary',
			//'#attributes'=> array('onclick'=>'forms_form()'),
		);
	//$build = [];
    $form['#theme'] = 'horizon_form';
    $form['result']['res']=$result;

	//$form['#horizon_form']='horizon_form';




    $form['#attached']['library'] = 'horizonblue/horizonblue.style';
  
		return $form;
	}
	public function submitForm(array &$form, FormStateInterface $form_state) {



		$values=$form_state->getValues();
		$searchValue= $values["search"];
		$url = Url::fromRoute('horizonblue.display');
		$form_state->setRedirectUrl($url);

    }
}
?>


	
